package com.example.amqpspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmqpSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmqpSpringApplication.class, args);
    }

}
