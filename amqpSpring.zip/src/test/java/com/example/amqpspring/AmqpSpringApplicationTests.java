package com.example.amqpspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmqpSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
